using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AccountStats
{
    public int Damage;
    public int Hp;
    public float BlockChance;

    public AccountStats(int damage, int hp, float blockChance)
    {
        Damage = damage;
        Hp = hp;
        BlockChance = blockChance;
    }
}

