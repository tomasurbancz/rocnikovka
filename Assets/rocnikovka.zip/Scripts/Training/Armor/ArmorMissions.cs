using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ArmorMissions : MissionList
{
    public override List<Mission> GetMissions()
    {
        List<Mission> missions = new List<Mission>();
        missions.Add(new Mission(MissionType.APPLES, 10, 0));
        missions.Add(new Mission(MissionType.STARS, 5, 1));
        return missions;
    }
}
