using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum MissionType
{
    SCORE, APPLES, STARS, STARS_IN_ROW, TIME
}
